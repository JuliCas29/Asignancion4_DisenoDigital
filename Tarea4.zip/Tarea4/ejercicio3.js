const fs = require('node:fs/promises')

async function readFromFile() {
  try {
    const data = await fs.readFile('archivo.txt', 'utf8')
    console.log(data)
  } catch (error) {
    console.error(error)
  }
}

readFromFile();
