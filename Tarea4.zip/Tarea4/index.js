const express = require('express');
const puertolibre = require('./ejercicio1')
const  infosistema = require('./ejercicio2')
const lecpromise= require('./ejercicio3')

const app = express()
const PORT = 3000 // Puerto para el servidor web

app.get('/', async (req, res) => {
    try {
        const freePort = await puertolibre()
        const systemInfo = infosistema()
        const fileContent = await lecpromise('archivo.txt')

        const data = {
            freePort,
            systemInfo,
            fileContent,
        };

        res.json(data)
    } catch (error) {
        res.status(500).json({ error: error.message })
    }
});

app.listen(PORT, () => {
    console.log(`Servidor iniciado en http://localhost:${PORT}`)
})