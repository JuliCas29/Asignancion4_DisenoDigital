const app = require('node:http')

const server = app.createServer((req, res) => {

    res.write('<h1> Ejercicio1 </h1>')
    res.end()
})

server.listen(0, () => {

    const port = server.address().port
    console.log(`Servidor ejecutandose en: http://localhost:${port}`)

})
