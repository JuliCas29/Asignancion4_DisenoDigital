const os = require('node:os')

console.log(os.platform()) //Sistema operativo
console.log(os.release()) //Versión del sistema operativo
console.log(os.totalmem()) //'Memoria total
console.log(os.freemem()) // Memoria libre 
console.log( os.arch()) //Arquitectura CPU
console.log( os.cpus()) //Número de procesadores lógicos
  